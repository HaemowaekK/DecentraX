const { createHelia } = require("helia");
const { unixfs } = require("@helia/unixfs");
const fs = require("fs").promises; // ✅ Use fs.promises for async read

async function createIPFSNode() {
    console.log("🚀 Initializing Helia IPFS node...");
    const helia = await createHelia();
    console.log("✅ Helia IPFS node initialized!");
    return unixfs(helia);
}

// Store a file on IPFS
async function storeFileOnIPFS(filePath) {
    try {
        console.log(`📂 Reading file: ${filePath}`);
        const fileBuffer = await fs.readFile(filePath);

        const fsAPI = await createIPFSNode();
        console.log("🚀 Storing file on IPFS...");
        const cid = await fsAPI.addBytes(new Uint8Array(fileBuffer));

        console.log(`✅ File stored on IPFS! CID: ${cid.toString()}`);
        return cid.toString();
    } catch (error) {
        console.error("❌ Error storing file on IPFS:", error);
        throw error;
    }
}

// Retrieve a file from IPFS
async function retrieveFileFromIPFS(cid) {
    try {
        console.log(`🔍 Retrieving file from IPFS CID: ${cid}`);
        const fsAPI = await createIPFSNode();
        let fileData = Buffer.alloc(0);

        for await (const chunk of fsAPI.cat(cid)) {
            fileData = Buffer.concat([fileData, chunk]);
        }

        console.log("✅ File retrieved successfully from IPFS!");
        return fileData;
    } catch (error) {
        console.error("❌ Error retrieving file from IPFS:", error);
        throw error;
    }
}

// ✅ Export functions for CommonJS
module.exports = { storeFileOnIPFS, retrieveFileFromIPFS };
