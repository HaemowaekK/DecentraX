const users = {}; // Temporary user store

function registerUser(address, role) {
    users[address] = { role, registered: true };
}

function getUserRole(address) {
    return users[address]?.role || "Guest";
}

module.exports = { registerUser, getUserRole };
