const { ethers } = require("ethers");
const dotenv = require("dotenv");
const contractABI = require("../artifacts/contracts/SecureFileTransfer.sol/SecureFileTransfer.json"); // ✅ Use require() for CommonJS

dotenv.config();

const provider = new ethers.providers.JsonRpcProvider("https://rpc-amoy.polygon.technology"); // ✅ Fixed provider
const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
const contract = new ethers.Contract(process.env.CONTRACT_ADDRESS, contractABI.abi, wallet);

async function storeFileOnBlockchain(cid) {
    try {
        console.log(`🚀 Storing file on Blockchain... CID: ${cid}`);
        const tx = await contract.storeFile(cid);
        await tx.wait();
        console.log("✅ File stored on Blockchain!");
    } catch (error) {
        console.error("❌ Error storing file on Blockchain:", error);
        throw error;
    }
}

async function grantAccessOnBlockchain(cid, recipientAddress) {
    try {
        console.log(`🚀 Granting access to ${recipientAddress} for CID: ${cid}`);
        const tx = await contract.grantAccess(cid, recipientAddress);
        await tx.wait();
        console.log("✅ Access granted!");
    } catch (error) {
        console.error("❌ Error granting access:", error);
        throw error;
    }
}

async function getFileFromBlockchain(cid) {
    try {
        console.log(`🔍 Fetching CID from Blockchain: ${cid}`);
        return await contract.getFile(cid);
    } catch (error) {
        console.error("❌ Error fetching file from Blockchain:", error);
        throw error;
    }
}


module.exports = { storeFileOnBlockchain, grantAccessOnBlockchain, getFileFromBlockchain };
