const dotenv = require("dotenv");
const express = require("express");
const cors = require("cors");
const multer = require("multer");
const fs = require("fs").promises; // ✅ Use require("fs").promises for async read
const { storeFileOnIPFS, retrieveFileFromIPFS } = require("./ipfs.js");
const { storeFileOnBlockchain, grantAccessOnBlockchain, getFileFromBlockchain } = require("./blockchain.js");
const { registerUser, getUserRole } = require("./auth.js");

dotenv.config();
const app = express();
const port = 5000;

app.use(express.json());
app.use(cors());

// Multer for file uploads
const storage = multer.diskStorage({
    destination: "uploads/",
    filename: (req, file, cb) => cb(null, file.originalname),
});
const upload = multer({ storage: storage });

// User Registration
app.post("/register", (req, res) => {
    try {
        const { address, role } = req.body;
        registerUser(address, role);
        res.json({ success: true, message: "User registered successfully", role });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error registering user", error });
    }
});

// Upload file
app.post("/upload", upload.single("file"), async (req, res) => {
    try {
        const filePath = req.file.path;
        const cid = await storeFileOnIPFS(filePath);
        await storeFileOnBlockchain(cid);

        res.json({ success: true, message: "File uploaded successfully", cid });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error uploading file", error });
    }
});

// Grant access
app.post("/grant-access", async (req, res) => {
    try {
        await grantAccessOnBlockchain(req.body.cid, req.body.recipientAddress);
        res.json({ success: true, message: "Access granted successfully" });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error granting access", error });
    }
});

// Retrieve file
app.get("/retrieve/:cid", async (req, res) => {
    try {
        const cid = await getFileFromBlockchain(req.params.cid);
        const file = await retrieveFileFromIPFS(cid);

        res.json({ success: true, file });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error retrieving file", error });
    }
});

app.listen(port, () => console.log(`✅ Server running on port ${port}`));
