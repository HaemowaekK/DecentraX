const { storeFileOnIPFS } = require("./ipfs.js"); 

async function test() {
    try {
        const cid = await storeFileOnIPFS("test.txt");
        console.log("✅ File uploaded successfully! CID:", cid);
    } catch (error) {
        console.error("❌ Error:", error);
    }
}

test();
